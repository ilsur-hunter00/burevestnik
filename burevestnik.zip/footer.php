<footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-2 col-md-2 col-sm-2">
            <div class="footer-block">
              <ul>
                <div class="footerhead">Меню</div>
                <li><a href="index.php">Главная</a></li>
                <li><a href="licenses.php">Документы</a></li>
                <li><a href="service.php">Заказать услугу</a></li>
                <li><a href="contact.php">Контакты</a></li>
                <div class="visible-xs">ООО "Буревестник"</div>
              </ul>
            </div>
          </div>
          <div class="col-lg-5 col-md-5 col-sm-5 hidden-xs">
            <div class="footer-block">
              <ul>
                <div class="footerhead">Услуги</div>
                <li><a href="tbo.php">Вывоз твердых отходов в Казани</a></li>
                <li><a href="jbo.php">Вывоз ЖБО (жидких бытовых отходов) в Казани</a></li>
                <li><a href="strMus.php">Вывоз строительного мусора</a></li>
                <li><a href="krupnogab.php">Вывоз крупногабаритных грузов</a></li>
                <li><a href="snow.php">Вывоз снега</a></li>
              </ul>
            </div>
          </div>
          <div class="col-lg-5 col-md-5 col-sm-5 hidden-xs">
            <div class="footer-block">
              <div class="footerhead">Контакты</div>
              <table>
                <tr><th>Адрес: </th><td>420127, РТ, Казань, ул. Дементьева, 45</td></tr> 
                <tr><th>Телефон:</th><td>+7 (987) 226-36-26</td></tr> 
                <tr><th>Время работы: </th><td>Понедельник-пятница с 8:00 до 17:00</td></tr> 
                <tr><th>E-mail:</th><td><a href="mailto:burtbo@mail.ru">burtbo@mail.ru</a></td></tr>
              </table>
            </div>
          </div>
        </div>
      </div>
    </footer>