<div class="panel panel-info hidden-md hidden-sm hidden-xs">
  <div class="panel-heading">
    <div class="sidebar-header"><i class="glyphicon glyphicon-option-vertical" aria-hidden="true"></i>Услуги</div>
  </div>
  <div class="panel-body">
    <ul class="list-group">
      <li class="list-group-item list-group-warning">
        <a href="tbo.php">Вывоз твердых отходов в Казани</a>
      </li>
      <li class="list-group-item list-group-warning">
        <a href="jbo.php">Вывоз ЖБО (жидких бытовых отходов) в Казани</a>
      </li>
      <li class="list-group-item list-group-warning">
        <a href="strMus.php">Вывоз строительного мусора</a>
      </li>
      <li class="list-group-item list-group-warning">
        <a href="krupnogab.php">Вывоз крупногабаритных грузов</a>
      </li>   
      <li class="list-group-item list-group-warning">
        <a href="snow.php">Вывоз снега</a>
      </li>
    </ul>
  </div>
</div>